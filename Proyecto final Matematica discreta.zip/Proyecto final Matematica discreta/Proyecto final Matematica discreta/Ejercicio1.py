conjunto_a = {"a", 2, "c", 3, "e", 4, "g", 5, "i", 6, "k", 7, "m"}
conjunto_b = {"a", "b", "c", "d", "e", "f", "g", "h", "i"}

diferencia_a_b = conjunto_a - conjunto_b

print("Conjunto A:", conjunto_a)
print("Conjunto B:", conjunto_b)
print("Resultado de la diferencia A-B:", diferencia_a_b)
