num_combinaciones_digitos = 10 ** 3

num_combinaciones_letras = 27 ** 3

total_combinaciones = num_combinaciones_digitos * num_combinaciones_letras

print("Número total de placas posibles en Guatemala:", total_combinaciones)
